

const example = function(a, b, c) {
    return a + b + c;
};
