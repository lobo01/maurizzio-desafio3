

const suma = (a, b) => a + b;
